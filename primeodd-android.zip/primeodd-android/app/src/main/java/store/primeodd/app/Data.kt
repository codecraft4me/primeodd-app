package store.primeodd.app

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

const val BASE_URL = "https://primeodd.store"

data class Pred(
    val id: Int, val slug: String, val home: String, val away: String, val league: String, val country: String,
    val kickoff: String, val time: String, val tip: String?, val odd: Double?, val confidence: Int,
    val analysis: String?, val vip: Boolean, val status: String, val score: String, val locked: Boolean,
    val image: String?, val url: String
)

data class Plan(
    val id: Int, val title: String, val image: String?, val price: String, val duration: String, val odd: String,
    val comment: String, val badge: String, val whatsapp: String, val telegram: String, val email: String, val phone: String
)

data class LiveMatch(val id: Int, val league: String, val home: String, val away: String, val hs: Int, val aw: Int, val minute: Int, val status: String)

data class Stats(val won: Int = 0, val lost: Int = 0, val total: Int = 0, val rate: Int = 0)

private fun JSONObject.s(k: String): String = if (!has(k) || isNull(k)) "" else optString(k)
private fun JSONObject.sn(k: String): String? = if (!has(k) || isNull(k)) null else optString(k)

private fun parsePred(o: JSONObject) = Pred(
    o.optInt("id"), o.s("slug"), o.s("home"), o.s("away"), o.s("league"), o.s("country"),
    o.s("kickoff"), o.s("time"), o.sn("tip"), if (o.isNull("odd") || !o.has("odd")) null else o.optDouble("odd"),
    o.optInt("confidence"), o.sn("analysis"), o.optBoolean("vip"), o.s("status"), o.s("score"),
    o.optBoolean("locked"), o.sn("image"), o.s("url")
)

private fun parsePlan(o: JSONObject) = Plan(
    o.optInt("id"), o.s("title"), o.sn("image"), o.s("price"), o.s("duration"), o.s("odd"), o.s("comment"),
    o.s("badge"), o.s("whatsapp"), o.s("telegram"), o.s("email"), o.s("phone")
)

private fun <T> JSONArray.map2(f: (JSONObject) -> T): List<T> = (0 until length()).map { f(getJSONObject(it)) }

object Api {
    suspend fun home(day: Int): JSONObject = get("a=home&day=$day")

    suspend fun get(q: String): JSONObject = withContext(Dispatchers.IO) {
        val c = URL("$BASE_URL/api.php?$q").openConnection() as HttpURLConnection
        c.connectTimeout = 15000
        c.readTimeout = 25000
        c.setRequestProperty("Accept", "application/json")
        try {
            JSONObject(c.inputStream.bufferedReader().readText())
        } finally {
            c.disconnect()
        }
    }
}

class AppVm : ViewModel() {
    var loading by mutableStateOf(true)
    var error by mutableStateOf<String?>(null)
    var day by mutableStateOf(0)
    var preds by mutableStateOf(listOf<Pred>())
    var results by mutableStateOf(listOf<Pred>())
    var plans by mutableStateOf(listOf<Plan>())
    var stats by mutableStateOf(Stats())
    var whatsapp by mutableStateOf("")
    var telegram by mutableStateOf("")
    var detail by mutableStateOf<Pred?>(null)
    var live by mutableStateOf(listOf<LiveMatch>())
    var liveNote by mutableStateOf("")
    var liveLoading by mutableStateOf(false)
    var social by mutableStateOf(listOf<Pair<String, String>>())

    init { load() }

    fun load(newDay: Int = day) {
        day = newDay
        viewModelScope.launch {
            loading = true
            error = null
            try {
                val j = Api.home(day)
                preds = j.getJSONArray("predictions").map2(::parsePred)
                results = j.getJSONArray("results").map2(::parsePred)
                plans = j.getJSONArray("plans").map2(::parsePlan)
                val st = j.getJSONObject("stats")
                stats = Stats(st.optInt("won"), st.optInt("lost"), st.optInt("total"), st.optInt("rate"))
                val so = j.optJSONObject("social") ?: JSONObject()
                social = so.keys().asSequence().map { k -> k to so.optString(k) }.filter { it.second.isNotBlank() }.toList()
                val site = j.optJSONObject("site")
                whatsapp = site?.s("whatsapp") ?: ""
                telegram = site?.s("telegram") ?: ""
            } catch (e: Exception) {
                error = "Cannot reach primeodd.store. Check your connection."
            }
            loading = false
        }
    }

    fun loadLive() {
        viewModelScope.launch {
            liveLoading = true
            try {
                val j = Api.get("a=live")
                val arr = j.optJSONArray("live") ?: JSONArray()
                live = (0 until arr.length()).map {
                    val o = arr.getJSONObject(it)
                    LiveMatch(o.optInt("id"), o.s("league"), o.s("home"), o.s("away"), o.optInt("hs"), o.optInt("as"), o.optInt("minute"), o.s("status"))
                }
                liveNote = j.optString("note")
            } catch (e: Exception) {
                liveNote = "Cannot load live scores. Check your connection."
            }
            liveLoading = false
        }
    }
}
