package store.primeodd.app

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

val Bg = Color(0xFF08080C)
val Card = Color(0xFF14141D)
val Card2 = Color(0xFF0D0D14)
val Line = Color(0xFF262633)
val Muted = Color(0xFF9B9BAB)
val Or1 = Color(0xFFFFA000)
val Or2 = Color(0xFFFF6A00)
val Or3 = Color(0xFFFF3D00)
val Win = Color(0xFF22C55E)
val Loss = Color(0xFFEF4444)
val Fire = Brush.linearGradient(listOf(Or1, Or2, Or3))

/** Ticket with half-circle notches cut into both sides – the signature shape of the app. */
class TicketShape(private val notchPx: Float, private val notch: Dp = 11.dp, private val corner: Dp = 22.dp) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val r = with(density) { corner.toPx() }
        val n = with(density) { notch.toPx() }
        val base = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
        val y = notchPx
        val left = Path().apply { addOval(Rect(Offset(-n, y - n), Size(n * 2, n * 2))) }
        val right = Path().apply { addOval(Rect(Offset(size.width - n, y - n), Size(n * 2, n * 2))) }
        val a = Path.combine(PathOperation.Difference, base, left)
        return Outline.Generic(Path.combine(PathOperation.Difference, a, right))
    }
}

@Composable
fun PrimeTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(primary = Or2, background = Bg, surface = Card, onSurface = Color.White, onBackground = Color.White),
        content = content
    )
}

val ScreenPad = PaddingValues(horizontal = 16.dp)
