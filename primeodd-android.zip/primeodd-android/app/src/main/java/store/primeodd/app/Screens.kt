package store.primeodd.app

import android.content.Intent
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

@Composable
fun PrimeApp(vm: AppVm = viewModel()) {
    var tab by remember { mutableIntStateOf(0) }
    BackHandler(enabled = vm.detail != null) { vm.detail = null }
    Column(Modifier.fillMaxSize().background(Bg).statusBarsPadding()) {
        Box(Modifier.weight(1f)) {
            val d = vm.detail
            if (d != null) DetailScreen(d, vm) else when (tab) {
                0 -> HomeScreen(vm)
                1 -> ResultsScreen(vm)
                else -> VipScreen(vm)
            }
        }
        if (vm.detail == null) BottomPill(tab) { tab = it }
    }
}

@Composable
private fun Brand() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(painterResource(R.drawable.logo_mark), null, Modifier.size(38.dp))
        Spacer(Modifier.width(8.dp))
        Text("prime", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text("odd", color = Or2, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Ticker(list: List<Pred>) {
    val text = list.filter { !it.locked && it.odd != null }
        .joinToString("     \u25CF     ") { "${it.home} v ${it.away}  ${it.tip}  @ ${"%.2f".format(it.odd)}" }
        .ifBlank { "Daily football predictions  \u25CF  VIP sure odds  \u25CF  Verified results" }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 10.dp).background(Card2).border(BorderStroke(1.dp, Line)).padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.padding(horizontal = 10.dp).size(8.dp).clip(CircleShape).background(Or2))
        Text(text, color = Color(0xFFE6E6EE), fontSize = 13.sp, maxLines = 1, modifier = Modifier.basicMarquee(iterations = Int.MAX_VALUE, velocity = 40.dp))
    }
}

@Composable
private fun HomeScreen(vm: AppVm) {
    LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp, 8.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Brand()
                IconButton(onClick = { vm.load() }) { Icon(Icons.Rounded.Refresh, "Refresh", tint = Muted) }
            }
        }
        item { Ticker(vm.preds) }
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Text("Win rate", color = Muted, fontSize = 13.sp)
                Row(verticalAlignment = Alignment.Bottom) {
                    Text("${vm.stats.rate}%", fontSize = 64.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 64.sp,
                        style = androidx.compose.ui.text.TextStyle(brush = Fire))
                    Spacer(Modifier.width(12.dp))
                    Text("${vm.stats.won} won / ${vm.stats.lost} lost\non settled tips", color = Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Yesterday" to -1, "Today" to 0, "Tomorrow" to 1).forEach { (l, d) ->
                        val on = vm.day == d
                        Text(l, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp,
                            modifier = Modifier.clip(RoundedCornerShape(50)).then(if (on) Modifier.background(Fire) else Modifier.background(Card).border(1.dp, Line, RoundedCornerShape(50)))
                                .clickable { vm.load(d) }.padding(horizontal = 16.dp, vertical = 8.dp))
                    }
                }
                Spacer(Modifier.height(14.dp))
            }
        }
        if (vm.loading) item { Box(Modifier.fillMaxWidth().padding(40.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Or2) } }
        vm.error?.let { e -> item { Notice(e, "Try again") { vm.load() } } }
        if (!vm.loading && vm.error == null && vm.preds.isEmpty()) item { Notice("No predictions for this day yet. New tips are published daily.", null) {} }
        items(vm.preds, key = { it.id }) { p ->
            TicketCard(p, Modifier.padding(horizontal = 16.dp, vertical = 6.dp)) { vm.detail = p }
        }
    }
}

@Composable
private fun Notice(msg: String, action: String?, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().padding(16.dp).clip(RoundedCornerShape(20.dp)).border(1.dp, Line, RoundedCornerShape(20.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Text(msg, color = Muted, textAlign = TextAlign.Center)
        if (action != null) {
            Spacer(Modifier.height(12.dp))
            FireButton(action, onClick = onClick)
        }
    }
}

@Composable
fun StatusChip(status: String) {
    val (label, c) = when (status) {
        "won" -> "WON" to Win
        "lost" -> "LOST" to Loss
        "void" -> "VOID" to Muted
        else -> "PENDING" to Or1
    }
    Text(label, color = c, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold,
        modifier = Modifier.clip(RoundedCornerShape(50)).background(c.copy(alpha = .14f)).padding(horizontal = 10.dp, vertical = 4.dp))
}

@Composable
fun TicketCard(p: Pred, modifier: Modifier = Modifier, onClick: () -> Unit) {
    var topH by remember { mutableIntStateOf(0) }
    val shape = remember(topH) { TicketShape(topH.toFloat()) }
    Column(
        modifier.fillMaxWidth().clip(shape).background(if (p.vip) Brush.verticalGradient(listOf(Color(0xFF241810), Card)) else Brush.verticalGradient(listOf(Card, Card)))
            .border(1.dp, if (p.vip) Color(0xFF4A3118) else Line, shape)
            .drawBehind {
                if (topH > 0) drawLine(Line, Offset(22.dp.toPx(), topH.toFloat()), Offset(size.width - 22.dp.toPx(), topH.toFloat()), 2f,
                    pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
            }
            .clickable { onClick() }
    ) {
        Column(Modifier.onSizeChanged { topH = it.height }.padding(18.dp, 16.dp, 18.dp, 16.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(listOf(p.country, p.league).filter { it.isNotBlank() }.joinToString(" - "), color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                Text(p.time, color = Or1, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            }
            Spacer(Modifier.height(10.dp))
            Text(p.home, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("vs", color = Or2, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(p.away, fontSize = 20.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(Modifier.fillMaxWidth().padding(18.dp, 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                if (p.locked) {
                    Text("VIP sure tip", fontWeight = FontWeight.Bold, color = Or1)
                    Text("Locked - subscribe to unlock", color = Muted, fontSize = 12.sp)
                } else {
                    Text(p.tip ?: "", fontWeight = FontWeight.Bold, fontSize = 16.sp, maxLines = 2)
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StatusChip(p.status)
                        Spacer(Modifier.width(8.dp))
                        Text("${p.confidence}% sure", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            Text(if (p.locked) "?.??" else "%.2f".format(p.odd ?: 0.0), fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
                style = androidx.compose.ui.text.TextStyle(brush = Fire))
        }
    }
}

@Composable
fun FireButton(text: String, modifier: Modifier = Modifier, icon: ImageVector? = null, onClick: () -> Unit) {
    Row(
        modifier.clip(RoundedCornerShape(14.dp)).background(Fire).clickable { onClick() }.padding(horizontal = 20.dp, vertical = 13.dp),
        horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun SolidButton(text: String, bg: Color, fg: Color, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Text(text, color = fg, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
        modifier = modifier.clip(RoundedCornerShape(14.dp)).background(bg).clickable { onClick() }.padding(vertical = 13.dp))
}

@Composable
private fun DetailScreen(p: Pred, vm: AppVm) {
    val ctx = LocalContext.current
    val ui = LocalUriHandler.current
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 32.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { vm.detail = null }) { Icon(Icons.Rounded.ArrowBack, "Back") }
                Text("Prediction", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            }
        }
        item {
            Text("${p.home} vs ${p.away}", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 30.sp)
            Text("${p.kickoff}  -  ${p.time}  -  ${p.league}", color = Muted, fontSize = 13.sp)
        }
        if (p.locked) {
            item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).border(1.dp, Color(0xFF4A3118), RoundedCornerShape(22.dp)).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(Icons.Rounded.Lock, null, tint = Or2, modifier = Modifier.size(44.dp))
                    Spacer(Modifier.height(8.dp))
                    Text("VIP sure tip", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Text("The pick, odds and analysis go to VIP members before kick-off.", color = Muted, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(14.dp))
                    FireButton("Get VIP sure games", Modifier.fillMaxWidth(), Icons.Rounded.Diamond) { vm.detail = null }
                }
            }
        } else {
            item {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(22.dp)).background(Card).border(1.dp, Line, RoundedCornerShape(22.dp)).padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Our pick", color = Muted, fontSize = 12.sp)
                        Text(p.tip ?: "", fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                        Spacer(Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) { StatusChip(p.status); if (p.score.isNotBlank()) Text("   FT ${p.score}", color = Muted) }
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("%.2f".format(p.odd ?: 0.0), fontSize = 42.sp, fontWeight = FontWeight.ExtraBold, style = androidx.compose.ui.text.TextStyle(brush = Fire))
                        Text("${p.confidence}% confidence", color = Muted, fontSize = 12.sp)
                    }
                }
            }
            if (!p.analysis.isNullOrBlank()) item {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).padding(16.dp)) {
                    Text("Analysis", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(4.dp))
                    Text(p.analysis, color = Color(0xFFD0D0DA), lineHeight = 21.sp)
                }
            }
            if (p.image != null) item {
                AsyncImage(p.image, "Prediction slip", Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.FillWidth)
            }
            item {
                FireButton("Share prediction", Modifier.fillMaxWidth(), Icons.Rounded.Share) {
                    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, "${p.home} vs ${p.away}: ${p.tip} @ ${"%.2f".format(p.odd ?: 0.0)}\n${p.url}") }
                    ctx.startActivity(Intent.createChooser(i, "Share"))
                }
            }
        }
        item {
            Text("Open on website", color = Or2, modifier = Modifier.clickable { try { ui.openUri(p.url) } catch (_: Exception) {} }.padding(vertical = 4.dp))
        }
    }
}

@Composable
private fun ResultsScreen(vm: AppVm) {
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            Text("Results", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Every win and loss, posted openly.", color = Muted)
            Spacer(Modifier.height(10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatBox("Wins", vm.stats.won.toString(), Win, Modifier.weight(1f))
                StatBox("Losses", vm.stats.lost.toString(), Loss, Modifier.weight(1f))
                StatBox("Rate", "${vm.stats.rate}%", Or1, Modifier.weight(1f))
            }
        }
        items(vm.results, key = { it.id }) { r ->
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Card).clickable { vm.detail = r }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(4.dp).height(38.dp).clip(RoundedCornerShape(4.dp)).background(when (r.status) { "won" -> Win; "lost" -> Loss; else -> Muted }))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text("${r.home} vs ${r.away}", fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text("${r.kickoff} - ${r.tip ?: ""} @ ${"%.2f".format(r.odd ?: 0.0)}${if (r.score.isNotBlank()) " - FT ${r.score}" else ""}", color = Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                StatusChip(r.status)
            }
        }
        if (vm.results.isEmpty() && !vm.loading) item { Notice("No results posted yet.", null) {} }
    }
}

@Composable
private fun StatBox(label: String, value: String, c: Color, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(16.dp)).background(Card).padding(14.dp)) {
        Text(value, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = c)
        Text(label, color = Muted, fontSize = 12.sp)
    }
}

@Composable
private fun VipScreen(vm: AppVm) {
    val ui = LocalUriHandler.current
    fun open(u: String) { if (u.isNotBlank()) try { ui.openUri(u) } catch (_: Exception) {} }
    LazyColumn(contentPadding = PaddingValues(16.dp, 8.dp, 16.dp, 24.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Sure game VIP", fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
            Text("Pick a plan and message us. Tips are sent straight to your WhatsApp or Telegram.", color = Muted)
        }
        items(vm.plans, key = { it.id }) { pl ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Card).border(1.dp, if (pl.badge.isNotBlank()) Or2 else Line, RoundedCornerShape(24.dp))) {
                Box(Modifier.fillMaxWidth().height(120.dp).background(Fire), contentAlignment = Alignment.Center) {
                    if (pl.image != null) AsyncImage(pl.image, pl.title, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Text(pl.title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
                    if (pl.badge.isNotBlank()) Text(pl.badge, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.align(Alignment.TopStart).padding(10.dp).clip(RoundedCornerShape(50)).background(Color(0xCC000000)).padding(horizontal = 10.dp, vertical = 4.dp))
                }
                Column(Modifier.padding(18.dp)) {
                    Text(pl.title, fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
                    Row(verticalAlignment = Alignment.Bottom) {
                        Text(pl.price, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold, style = androidx.compose.ui.text.TextStyle(brush = Fire))
                        if (pl.duration.isNotBlank()) Text("  / ${pl.duration}", color = Muted, modifier = Modifier.padding(bottom = 6.dp))
                    }
                    if (pl.odd.isNotBlank()) Text("Odds: ${pl.odd}", color = Or1, fontWeight = FontWeight.SemiBold)
                    if (pl.comment.isNotBlank()) { Spacer(Modifier.height(6.dp)); Text(pl.comment, color = Color(0xFFD0D0DA)) }
                    Spacer(Modifier.height(14.dp))
                    if (pl.whatsapp.isNotBlank()) SolidButton("Subscribe on WhatsApp", Color(0xFF25D366), Color(0xFF052B12), Modifier.fillMaxWidth()) { open(pl.whatsapp) }
                    if (pl.telegram.isNotBlank()) { Spacer(Modifier.height(8.dp)); SolidButton("Subscribe on Telegram", Color(0xFF2AABEE), Color(0xFF04202F), Modifier.fillMaxWidth()) { open(pl.telegram) } }
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (pl.email.isNotBlank()) SolidButton("Email", Card2, Color.White, Modifier.weight(1f)) { open(pl.email) }
                        if (pl.phone.isNotBlank()) SolidButton("Call", Card2, Color.White, Modifier.weight(1f)) { open(pl.phone) }
                    }
                }
            }
        }
        if (vm.plans.isEmpty() && !vm.loading) item { Notice("Plans coming soon. Contact us on WhatsApp or Telegram.", null) {} }
    }
}

@Composable
private fun BottomPill(selected: Int, onSelect: (Int) -> Unit) {
    val items = listOf(Triple("Tips", Icons.Rounded.SportsSoccer, 0), Triple("Results", Icons.Rounded.Leaderboard, 1), Triple("VIP", Icons.Rounded.Diamond, 2))
    Box(Modifier.fillMaxWidth().navigationBarsPadding().padding(16.dp, 6.dp, 16.dp, 12.dp)) {
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(50)).background(Color(0xFF14141D)).border(1.dp, Line, RoundedCornerShape(50)).padding(6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly
        ) {
            items.forEach { (label, icon, i) ->
                val on = selected == i
                Row(
                    Modifier.weight(if (on) 1.6f else 1f).clip(RoundedCornerShape(50)).then(if (on) Modifier.background(Fire) else Modifier)
                        .clickable { onSelect(i) }.padding(vertical = 12.dp),
                    horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(icon, label, tint = if (on) Color.White else Muted, modifier = Modifier.size(22.dp))
                    if (on) { Spacer(Modifier.width(6.dp)); Text(label, color = Color.White, fontWeight = FontWeight.Bold) }
                }
            }
        }
    }
}
